<?php
echo "Hello, World!";
?>