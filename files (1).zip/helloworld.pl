:- initialization(main).

main :- write('Hello, World!'), nl.