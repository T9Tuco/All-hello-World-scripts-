-module(helloworld).
-export([start/0]).

start() ->
    io:format("Hello, World!~n").